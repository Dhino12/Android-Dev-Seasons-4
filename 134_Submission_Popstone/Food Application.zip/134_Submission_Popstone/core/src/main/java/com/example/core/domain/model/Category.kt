package com.example.core.domain.model

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

@Parcelize
data class Category (

        val category: String? = null,
        val key: String,
):Parcelable